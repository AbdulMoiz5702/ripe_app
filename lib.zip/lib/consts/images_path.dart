

// on boarding

const String calender = 'assets/imagesOnBording/calender.jpg';
const String message = 'assets/imagesOnBording/chat.jpg';
const String bookMark = 'assets/imagesOnBording/bookmark.jpg';
const String card = 'assets/imagesOnBording/card.jpg';

// role selection

const String driver = 'assets/roleSelection/driver.png';
const String pessenger = 'assets/roleSelection/passenger.png';

// login Option

const String google = 'assets/loginOption/gogole.png';
const String facebook = 'assets/loginOption/facebook.png';
const String mail = 'assets/loginOption/inbox.jpg';